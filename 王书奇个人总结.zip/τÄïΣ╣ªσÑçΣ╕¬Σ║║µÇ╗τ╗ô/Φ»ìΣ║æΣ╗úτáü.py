import pandas as pd
import jieba
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from collections import Counter
import re
from PIL import Image
import numpy as np
import warnings
warnings.filterwarnings('ignore')
df = pd.read_excel('/Users/shuqiwang/Downloads/我的阿勒泰小红书评论.xlsx')
print("数据列名：", df.columns.tolist())
print("数据行数：", len(df))
print("\n数据预览：")
print(df[['标题', '标题1', '作者', '时间', 'count']].head())
titles = df['标题1'].dropna().astype(str).tolist()
print(f"\n提取到{len(titles)}条笔记标题")
stopwords = set([
    '的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你',
    '会', '着', '没有', '看', '好', '自己', '之', '中', '与', '等', '来', '我们', '把', '还', '又', '什么', '这个', '那个',
    '年', '月', '日', '｜', '《', '》', '|', '#', '！', '？', '，', '。', '、', '：', '；', '（', '）', '【', '】', '～', '「', '」',
    '这部', '这部', '这部', '这部', '一部', '一部', '一部', '这部', '如何', '什么', '为什么', '怎么', '如何', '什么', '为什么', '怎么',
    '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的', '真的',
    '2024', '2024年', '2023', '2023年', '2022', '2022年', '2021', '2021年', '2020', '2020年', '2019', '2019年', '2018', '2018年',
    '我', '我的', '你', '你的', '他', '他的', '她', '她的', '它', '它的', '我们', '你们', '他们', '她们', '它们',
    '啊', '呀', '呢', '吗', '吧', '啦', '唉', '哦', '噢', '喔', '呵', '嘿', '嗨', '嗯',
    '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '百', '千', '万', '亿',
    '以及', '或者', '但是', '然而', '因为', '所以', '如果', '那么', '虽然', '可是', '即使', '而且',
    '可以', '可能', '能够', '应该', '必须', '需要', '想要', '希望', '愿意', '觉得', '认为', '以为', '知道', '了解',
    '非常', '特别', '十分', '极其', '相当', '比较', '稍微', '略微', '有点', '有些',
    '已经', '正在', '将要', '即将', '曾经', '刚刚', '马上', '立刻', '顿时', '突然', '渐渐', '慢慢',
    '这里', '那里', '这边', '那边', '这个', '那个', '这些', '那些',
    '时候', '时间', '时刻', '时期', '时代', '年代', '年份', '月份', '日子', '今天', '明天', '昨天',
    '地方', '地点', '位置', '区域', '地区', '地域', '空间',
    '事情', '事件', '事物', '东西', '物品', '物质', '材料',
    '方式', '方法', '办法', '途径', '手段', '策略', '技巧',
    '原因', '理由', '缘故', '因素', '条件', '前提',
    '结果', '效果', '成果', '成绩', '成就', '收获',
    '问题', '疑问', '难题', '困难', '挑战', '障碍',
    '感觉', '感受', '体会', '体验', '经验',
    '分析', '解析', '解读', '理解', '解释',
    '视角', '角度', '观点', '看法', '见解',
    '治愈', '神剧', '火爆', '出圈', '观后感', '剧评', '热播剧', '迷你剧', '短剧',
    '解析', '热点', '研究', '论文', '考研', '视角', '传播学', '新传', '文旅', '品牌', '营销',
    '解析', '热点', '研究', '论文', '考研', '视角', '传播学', '新传', '文旅', '品牌', '营销',
    '关于', '对于', '通过', '基于', '根据', '按照', '依照', '凭借', '依靠', '利用',
    '大家', '各位', '观众', '读者', '用户', '粉丝', '朋友', '同学', '老师', '专家',
    '一定', '一定', '一定', '一定', '一定', '一定', '一定', '一定', '一定', '一定',
    '一定', '一定', '一定', '一定', '一定', '一定', '一定', '一定', '一定', '一定',
    '分享', '推荐', '介绍', '展示', '呈现', '表达', '描述', '叙述', '说明', '阐述',
    '这些', '那些', '这个', '那个', '这种', '那种', '这类', '那类', '这样', '那样',
    '成为', '变成', '形成', '构成', '组成', '建立', '创建', '设立', '设置',
    '重要', '主要', '关键', '核心', '基本', '根本', '基础', '本质',
    '不同', '相同', '相似', '类似', '一样', '一致', '统一',
    '影响', '作用', '效果', '效益', '成效', '成果', '结果',
    '开始', '结束', '完成', '实现', '达到', '获得', '取得',
    '需要', '需求', '要求', '必要', '必须', '必需',
    '更多', '更多', '更多', '更多', '更多', '更多', '更多', '更多',
    '进行', '开展', '实施', '执行', '操作', '运行', '运转',
    '方面', '方向', '领域', '范围', '范畴', '区域',
    '过程', '流程', '程序', '步骤', '环节', '阶段',
    '其中', '其中', '其中', '其中', '其中', '其中',
    '一种', '一种', '一种', '一种', '一种', '一种',
    '各种', '各种', '各种', '各种', '各种', '各种',
    '一些', '一些', '一些', '一些', '一些', '一些',
    '很多', '很多', '很多', '很多', '很多', '很多',
    '可能', '可能', '可能', '可能', '可能', '可能',
    '可以', '可以', '可以', '可以', '可以', '可以',
    '应该', '应该', '应该', '应该', '应该', '应该',
    '大家', '大家', '大家', '大家', '大家', '大家',
    '现在', '现在', '现在', '现在', '现在', '现在',
    '然后', '然后', '然后', '然后', '然后', '然后',
    '最后', '最后', '最后', '最后', '最后', '最后',
    '同时', '同时', '同时', '同时', '同时', '同时',
    '一起', '一起', '一起', '一起', '一起', '一起',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
    '一样', '一样', '一样', '一样', '一样', '一样',
])
jieba.add_word('我的阿勒泰', freq=1000)
jieba.add_word('阿勒泰', freq=800)
jieba.add_word('李文秀', freq=300)
jieba.add_word('张凤侠', freq=300)
jieba.add_word('巴太', freq=300)
jieba.add_word('麦西拉', freq=200)
jieba.add_word('哈萨克族', freq=200)
jieba.add_word('爱奇艺', freq=150)
jieba.add_word('白玉兰', freq=150)
jieba.add_word('新传', freq=200)
jieba.add_word('传播学', freq=150)
jieba.add_word('文旅', freq=150)
jieba.add_word('影视', freq=150)
jieba.add_word('电视剧', freq=150)
jieba.add_word('治愈', freq=120)
jieba.add_word('治愈神剧', freq=150)
def clean_and_segment(texts):
    all_words = []
    for text in texts:
        text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9]', ' ', str(text))
        text = re.sub(r'\s+', ' ', text).strip()
        
        if text:
            words = jieba.lcut(text)
            filtered_words = [word for word in words if word not in stopwords and len(word) > 1]
            all_words.extend(filtered_words)
    
    return all_words
all_words = clean_and_segment(titles)
print(f"\n分词后得到{len(all_words)}个词语")
word_counts = Counter(all_words)
top_words = word_counts.most_common(50)

print("\n前50个高频词语：")
for i, (word, count) in enumerate(top_words[:50], 1):
    print(f"{i:2d}. {word:8s}: {count:3d}次")
def generate_wordcloud(word_counts, title="小红书《我的阿勒泰》评论词云"):
    wc = WordCloud(
        font_path='/System/Library/Fonts/PingFang.ttc',  
        width=800,
        height=600,
        background_color='white',
        max_words=200,
        max_font_size=150,
        min_font_size=10,
        random_state=42,
        collocations=False,  
        scale=2  
    )
    wc.generate_from_frequencies(word_counts)
    plt.figure(figsize=(15, 10))
    plt.imshow(wc, interpolation='bilinear')
    plt.axis('off')
    plt.title(title, fontsize=20, pad=20)
    plt.tight_layout()
    wc.to_file('我的阿勒泰词云.png')
    print(f"\n词云图已保存为: 我的阿勒泰词云.png")
    
    plt.show()
    
    return wc
wordcloud = generate_wordcloud(word_counts)
def analyze_by_category(word_counts):
    categories = {
        '剧集相关': ['阿勒泰', '我的阿勒泰', '电视剧', '剧集', '迷你剧', '短剧', '热播剧', '神剧', '华语剧'],
        '情感体验': ['治愈', '治愈神剧', '热泪盈眶', '治愈焦虑', '精神内耗', '瞬间释然', '感动', '喜欢', '热爱'],
        '角色分析': ['李文秀', '张凤侠', '巴太', '麦西拉', '女性', '角色', '人物', '哈萨克族', '民俗'],
        '专业分析': ['新传', '传播学', '文旅', '品牌', '营销', '热点', '论文', '研究', '分析', '视角'],
        '地域文化': ['新疆', '哈萨克族', '民俗文化', '地方感', '地域剧', '阿勒泰地区', '新疆阿勒泰'],
        '商业影响': ['爱奇艺', '品牌', '联名周边', '赚钱', '火爆出圈', '出海', '影旅潮流']
    }
    
    category_counts = {}
    for category, keywords in categories.items():
        count = 0
        matched_words = []
        for word, freq in word_counts.items():
            for keyword in keywords:
                if keyword in word or word in keyword:
                    count += freq
                    matched_words.append((word, freq))
                    break
        
        category_counts[category] = {
            'count': count,
            'words': sorted(matched_words, key=lambda x: x[1], reverse=True)[:10]
        }
    
    return category_counts
category_analysis = analyze_by_category(word_counts)

print("\n=== 主题分类分析 ===")
for category, data in category_analysis.items():
    print(f"\n{category} (共{data['count']}次提及):")
    top_words = data['words'][:5]
    if top_words:
        words_str = "、".join([f"{word}({count})" for word, count in top_words])
        print(f"  高频词: {words_str}")
def plot_category_distribution(category_analysis):
    categories = list(category_analysis.keys())
    counts = [data['count'] for data in category_analysis.values()]
    
    plt.figure(figsize=(12, 6))
    bars = plt.bar(categories, counts, color=['#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD'])
    
    plt.title('《我的阿勒泰》小红书评论主题分布', fontsize=16, pad=20)
    plt.xlabel('主题类别', fontsize=12)
    plt.ylabel('提及频次', fontsize=12)
    plt.xticks(rotation=15, ha='right')
    for bar, count in zip(bars, counts):
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height + 5,
                 f'{count}', ha='center', va='bottom', fontsize=10)
    
    plt.tight_layout()
    plt.savefig('主题分布.png', dpi=300, bbox_inches='tight')
    plt.show()
plot_category_distribution(category_analysis)
print(f"\n主题分布图已保存为: 主题分布.png")
if 'count' in df.columns and '作者' in df.columns:
    try:
        df_count = df.dropna(subset=['count'])
        df_count['count'] = pd.to_numeric(df_count['count'], errors='coerce')
        df_count = df_count.dropna(subset=['count'])
        author_stats = df_count.groupby('作者')['count'].agg(['sum', 'count']).sort_values('sum', ascending=False)
        author_stats.columns = ['总互动量', '笔记数量']
        
        print("\n=== 作者互动量TOP10 ===")
        print(author_stats.head(10))
        top_authors = author_stats.head(10)
        
        plt.figure(figsize=(12, 8))
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
        colors1 = plt.cm.Set3(range(len(top_authors)))
        bars1 = ax1.barh(range(len(top_authors)), top_authors['总互动量'], color=colors1)
        ax1.set_yticks(range(len(top_authors)))
        ax1.set_yticklabels(top_authors.index)
        ax1.invert_yaxis()
        ax1.set_xlabel('总互动量', fontsize=12)
        ax1.set_title('TOP10作者总互动量', fontsize=14, pad=15)
        colors2 = plt.cm.Set2(range(len(top_authors)))
        bars2 = ax2.barh(range(len(top_authors)), top_authors['笔记数量'], color=colors2)
        ax2.set_yticks(range(len(top_authors)))
        ax2.set_yticklabels(top_authors.index)
        ax2.invert_yaxis()
        ax2.set_xlabel('笔记数量', fontsize=12)
        ax2.set_title('TOP10作者笔记数量', fontsize=14, pad=15)
        
        plt.tight_layout()
        plt.savefig('作者分析.png', dpi=300, bbox_inches='tight')
        plt.show()
        print(f"\n作者分析图已保存为: 作者分析.png")
        
    except Exception as e:
        print(f"\n作者分析时出现错误: {e}")

print("\n=== 分析完成 ===")
