import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os

# -------------------------- 1. 指定中文字体 --------------------------
font_path = "C:/Windows/Fonts/msyh.ttc" if os.path.exists("C:/Windows/Fonts/msyh.ttc") else "C:/Windows/Fonts/simhei.ttf"
from matplotlib.font_manager import FontProperties
chinese_font = FontProperties(fname=font_path, size=10) 

plt.rcParams['axes.unicode_minus'] = False 
plt.figure(figsize=(16, 6), facecolor='white') 


# -------------------------- 2. 读取数据 --------------------------
file_path = "C:/Users/张佳俊/Desktop/三景区评论_清洗合并后.xlsx"
df = pd.read_excel(file_path)
df_target = df[df["景区名称"] == "喀纳斯"].copy()
if len(df_target) == 0:
    raise ValueError("喀纳斯景区数据为空！请检查合并文件中的景区名称是否正确")

# 按“月”聚合评论量
df_target["发布月份"] = df_target["评论时间_清洗后"].dt.to_period("M")
monthly_counts = df_target.groupby("发布月份").size().reset_index(name="月点评数量")
# 转换格式：便于坐标轴识别日期
monthly_counts["发布月份_str"] = monthly_counts["发布月份"].astype(str)
monthly_counts["发布月份_dt"] = pd.to_datetime(monthly_counts["发布月份_str"])
monthly_counts = monthly_counts.sort_values("发布月份_dt")


# -------------------------- 3. 绘制折线图 --------------------------
ax = plt.gca()

ax.plot(
    monthly_counts["发布月份_dt"],
    monthly_counts["月点评数量"],
    color="#2E86AB", 
    linewidth=2.2,
    marker='o',      
    markersize=4.5,
    alpha=0.9
)

ax.fill_between(
    monthly_counts["发布月份_dt"],
    monthly_counts["月点评数量"],
    color="#2E86AB",
    alpha=0.12
)


# -------------------------- 4. 优化坐标轴与标签 --------------------------
ax.xaxis.set_major_locator(mdates.MonthLocator(interval=6))
ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m')) 
plt.xticks(rotation=45, ha='right', fontproperties=chinese_font, fontsize=10.5)
plt.yticks(fontproperties=chinese_font, fontsize=10.5)

# 坐标轴标签
ax.set_xlabel("发布月份", fontproperties=chinese_font, fontsize=12.5, labelpad=12)
ax.set_ylabel("月点评数量（条）", fontproperties=chinese_font, fontsize=12.5, labelpad=12)

# 图表标题
plt.title(
    "阿勒泰三大热门景区所有时间段月点评数量趋势",
    fontproperties=chinese_font,
    fontsize=15,
    fontweight='bold',
    pad=22  # 标题与图表间距，避免拥挤
)

ax.grid(axis='y', alpha=0.35, linestyle='--', linewidth=0.9)
ax.set_axisbelow(True)  


# -------------------------- 5. 保存图表 --------------------------
# 保存路径
save_path = "C:/Users/张佳俊/Desktop/阿勒泰三大热门景区所有时间段月点评数量趋势.png"
# 高清保存（300dpi），避免标签被截断
plt.tight_layout()
plt.savefig(
    save_path,
    dpi=300,
    bbox_inches='tight',
    facecolor='white' 
)
plt.close() 


# -------------------------- 6. 结果提示 --------------------------
print("="*50)
print("✅ 折线图生成成功！")
print(f"📊 图表内容：阿勒泰三大热门景区所有时间段月点评数量趋势")
print(f"📅 数据时间范围：{monthly_counts['发布月份_str'].min()} 至 {monthly_counts['发布月份_str'].max()}")
print(f"💾 保存路径：{save_path}")
print("="*50)
