import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import jieba
import os

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']
plt.rcParams['axes.unicode_minus'] = False

file_path = "C:/Users/张佳俊/Desktop/三景区评论_清洗合并后.xlsx"
df = pd.read_excel(file_path, usecols=["景区名称", "评论内容_清洗后"])
scenic_list = ["喀纳斯", "白哈巴", "禾木"]

emotion_dimensions = [
    "正向情感",   # 包含“美、推荐、值得”等
    "中性情感",   # 客观描述，无明显情绪
    "负向情感",   # 包含“差、失望、拥挤”等
    "IP关联词",   # 包含“我的阿勒泰、阿勒泰”等
    "景观关联词"  # 包含“湖、雪山、草原”等
]
dimension_keywords = {
    "正向情感": ["美", "好看", "推荐", "值得", "治愈", "震撼", "喜欢", "不错"],
    "中性情感": ["位置", "路线", "时间", "门票", "交通", "天气", "住宿"],
    "负向情感": ["差", "不好", "失望", "坑", "拥挤", "脏", "贵", "不值"],
    "IP关联词": ["我的阿勒泰", "阿勒泰", "剧里", "电视剧", "像剧里"],
    "景观关联词": ["湖", "雪山", "草原", "森林", "白桦林", "星空", "河"]
}

def calculate_emotion_dimensions(text_series):
    all_text = " ".join([str(t).strip().lower() for t in text_series])
    for words in dimension_keywords.values():
        for word in words:
            jieba.add_word(word)
    words = jieba.lcut(all_text)
    
    total_words = len(words)
    dimension_counts = []
    for dim in emotion_dimensions:
        count = sum(1 for word in words if word in dimension_keywords[dim])
        ratio = (count / total_words) * 100 if total_words > 0 else 0
        dimension_counts.append(ratio)
    return dimension_counts

emotion_data = {}
for scenic in scenic_list:
    df_current = df[df["景区名称"] == scenic].dropna()
    if len(df_current) == 0:
        emotion_data[scenic] = [0]*len(emotion_dimensions)
        continue
    emotion_data[scenic] = calculate_emotion_dimensions(df_current["评论内容_清洗后"])

angles = np.linspace(0, 2*np.pi, len(emotion_dimensions), endpoint=False).tolist()
angles += angles[:1]  
emotion_dimensions += emotion_dimensions[:1] 

fig, ax = plt.subplots(figsize=(10, 10), subplot_kw=dict(polar=True))
colors = ["#2E86AB", "#A23B72", "#F18F01"] 

for i, scenic in enumerate(scenic_list):
    data = emotion_data[scenic]
    data += data[:1] 
    ax.plot(angles, data, 'o-', linewidth=2, label=scenic, color=colors[i])
    ax.fill(angles, data, alpha=0.2, color=colors[i])

ax.set_xticks(angles[:-1])
ax.set_xticklabels(emotion_dimensions[:-1], fontsize=12)
ax.set_yticklabels([]) 
ax.set_title("三景区评论情感维度雷达图", fontsize=16, fontweight="bold", pad=20)
ax.legend(loc="upper right", fontsize=11)

save_path = "C:/Users/张佳俊/Desktop/三景区情感分布雷达图.png"
plt.tight_layout()
plt.savefig(save_path, dpi=300, bbox_inches="tight")
plt.close()

print(f"✅ 情感分布雷达图已保存至：{save_path}")
