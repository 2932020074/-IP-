import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import os
from datetime import datetime

font_path = "C:/Windows/Fonts/msyh.ttc"
from matplotlib.font_manager import FontProperties
chinese_font = FontProperties(fname=font_path, size=11)
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(16, 8), facecolor='white')


file_path = "C:/Users/张佳俊/Desktop/三景区评论_清洗合并后.xlsx"
df = pd.read_excel(file_path)
ip_start = pd.Timestamp("2024-05-01")
df["IP阶段"] = df["评论时间_清洗后"].apply(lambda x: "IP后" if x >= ip_start else "IP前")
df = df[(df["评分_清洗后"] >= 0) & (df["评分_清洗后"] <= 5)]


plt.title("三景区评论时间-评分关联散点图", fontproperties=chinese_font, fontsize=16, fontweight='bold', pad=20)

for phase, color in zip(["IP前", "IP后"], ["#2E86AB", "#A23B72"]):
    data = df[df["IP阶段"] == phase]
    plt.scatter(
        data["评论时间_清洗后"],
        data["评分_清洗后"],
        c=color,
        label=phase,
        alpha=0.6,
        s=30,
        edgecolors='white'
    )
plt.axvline(x=ip_start, color='red', linestyle='--', linewidth=2, label="IP首播（2024.05）")

plt.xlabel("评论发布时间", fontproperties=chinese_font, fontsize=13, labelpad=15)
plt.ylabel("评分（0-5分）", fontproperties=chinese_font, fontsize=13, labelpad=15)
plt.ylim(0, 5.5)
plt.yticks(range(0,6), fontproperties=chinese_font)
plt.legend(prop=chinese_font, fontsize=12)

plt.gca().xaxis.set_major_locator(mdates.MonthLocator(interval=6))
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
plt.xticks(rotation=45, ha='right', fontproperties=chinese_font, fontsize=10)
plt.grid(alpha=0.3, linestyle='--')

save_path = "C:/Users/张佳俊/Desktop/评论时间-评分散点图.png"
plt.tight_layout()
plt.savefig(save_path, dpi=300, bbox_inches='tight', facecolor='white')
plt.close()


print("="*60)
print("📊 评论时间-评分散点图 分析报告")
print("="*60)
low_before = len(df[(df["IP阶段"] == "IP前") & (df["评分_清洗后"] <= 2)])
low_after = len(df[(df["IP阶段"] == "IP后") & (df["评分_清洗后"] <= 2)])
print(f"IP前低分评论（≤2分）：{low_before}条")
print(f"IP后低分评论（≤2分）：{low_after}条")
print(f"\n💾 保存路径：{save_path}")
print("✅ 散点图生成成功！")
print("="*60)
