import pandas as pd
import matplotlib.pyplot as plt

# -------------------------- 1. 基础配置--------------------------
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
plt.figure(figsize=(12, 7), facecolor='white')


# -------------------------- 2. 读取数据 --------------------------
file_path = "C:/Users/张佳俊/Desktop/三景区评论_清洗合并后.xlsx"
df = pd.read_excel(file_path, usecols=["景区名称", "评论时间_清洗后"])
df = df.dropna()  # 过滤空值
# 划分IP阶段
df["IP阶段"] = df["评论时间_清洗后"].apply(lambda x: "IP前（2024.05前）" if x < pd.Timestamp("2024-05-01") else "IP后（2024.05-）")


# -------------------------- 3. 聚合数据 --------------------------
stack_data = df.groupby(["IP阶段", "景区名称"]).size().unstack(fill_value=0)
stack_data["总评论量"] = stack_data.sum(axis=1)


# -------------------------- 4. 绘制堆叠柱状图 --------------------------
# 绘制堆叠柱
stack_data.drop("总评论量", axis=1).plot(
    kind="bar",
    stacked=True,
    ax=plt.gca(),
    color=["#2E86AB", "#A23B72", "#F18F01"],
    alpha=0.8,
    width=0.6
)

for i, (ip_phase, row) in enumerate(stack_data.iterrows()):
    total = row["总评论量"]
    plt.text(i, total + 10, f"总：{total}条", ha="center", fontsize=10, fontweight="bold")

plt.title("三景区IP前后评论量堆叠占比图", fontsize=15, fontweight="bold", pad=20)
plt.xlabel("IP阶段", fontsize=12, labelpad=15)
plt.ylabel("评论量（条）", fontsize=12, labelpad=15)
plt.xticks(rotation=0, fontsize=11)
plt.legend(title="景区名称", fontsize=10, bbox_to_anchor=(1.05, 1), loc="upper left") 
plt.grid(axis="y", alpha=0.3, linestyle="--")

# -------------------------- 5. 保存图表 --------------------------
save_path = "C:/Users/张佳俊/Desktop/IP评论量堆叠占比图.png"
plt.tight_layout()
plt.savefig(save_path, dpi=300, bbox_inches="tight") 
plt.close()

# -------------------------- 分析报告 --------------------------
print("="*70)
print("📊 IP前后评论量堆叠占比图 分析报告")
print("="*70)
for ip_phase in stack_data.index:
    print(f"\n{ip_phase}：")
    total = stack_data.loc[ip_phase, "总评论量"]
    for scenic in stack_data.columns[:-1]:
        count = stack_data.loc[ip_phase, scenic]
        ratio = count / total * 100 if total != 0 else 0
        print(f"  · {scenic}：{count}条（占{ratio:.1f}%）")
print(f"\n💾 保存路径：{save_path}")
print("✅ 图表生成成功！")
print("="*70)
