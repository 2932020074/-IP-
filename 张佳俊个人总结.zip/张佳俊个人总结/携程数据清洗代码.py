import pandas as pd
import re
import numpy as np

# -------------------------- 1. 固定文件路径 --------------------------
file_paths = {
    "白哈巴": "C:/Users/张佳俊/Desktop/白哈巴.xlsx", 
    "禾木": "C:/Users/张佳俊/Desktop/禾木景区携程数据.xlsx",  
    "喀纳斯": "C:/Users/张佳俊/Desktop/喀纳斯景区携程评论.xlsx"  
}
output_path = "C:/Users/张佳俊/Desktop/三景区评论-清洗合并后.xlsx"


# -------------------------- 2. 数据清洗函数 --------------------------
def clean_scenic_comments(df, scenic_name):
    """
    清洗单个景区的评论数据
    df: 单个景区的原始Excel数据
    scenic_name: 景区名称（用于自动标记，无需手动提取）
    """
    df_clean = df.copy()
    
    # 1. 自动标记景区名称
    df_clean["景区名称"] = scenic_name
    
    # 2. 清洗“标题”列
    # 功能：去除特殊符号、过滤5字以内短评、保留有效内容
    def clean_comment_content(text):
        # 转为字符串并去除前后空格
        text = str(text).strip()
        # 过滤5字以内无意义评论（如“不错”“挺好”）
        if len(text) < 5:
            return np.nan
        # 去除特殊符号和乱码，只保留中文、英文、数字和常见标点
        text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z0-9\s，。！？；：、#@]", "", text)
        # 合并多个空格为单个空格，优化格式
        return re.sub(r"\s+", " ", text)
    
    # 新增“评论内容_清洗后”列，存储清洗后的评论
    df_clean["评论内容_清洗后"] = df_clean["标题"].apply(clean_comment_content)
    # 删除清洗后内容为空的行（即短评或乱码）
    df_clean = df_clean.dropna(subset=["评论内容_清洗后"], axis=0)
    
    # 3. 清洗“评论”列
    # 功能：从“5分 超棒”“4分 很好”中提取数字评分
    def extract_rating(rating_text):
        rating_text = str(rating_text).strip()
        # 提取文本中的数字（适配“5分”“4.5分”等格式）
        rating_match = re.search(r"\d+\.?\d*", rating_text)
        if rating_match:
            # 转为浮点数（如“5”→5.0，“4.5”→4.5）
            return float(rating_match.group())
        # 无法提取评分时设为无效值
        return np.nan
    
    # 新增“评分_清洗后”列，存储提取后的数字评分
    df_clean["评分_清洗后"] = df_clean["评论"].apply(extract_rating)
    # 删除无效评分
    df_clean = df_clean[(df_clean["评分_清洗后"] >= 0) & (df_clean["评分_清洗后"] <= 5)]
    
    # 4. 清洗“时间和IP属地”列
    # 功能：从“2024-10-14 IP属地XX”中提取“2024-10-14”并转为标准时间格式
    def extract_clean_date(time_text):
        time_text = str(time_text).strip()
        # 匹配“年-月-日”格式的日期（如2024-10-14、2023-05-20）
        date_match = re.search(r"\d{4}-\d{2}-\d{2}", time_text)
        if date_match:
            # 转为标准datetime格式，便于后续按时间分析
            return pd.to_datetime(date_match.group(), errors="coerce")
        # 无法提取日期时设为无效值
        return np.nan
    
    # 新增“评论时间_清洗后”列，存储标准格式日期
    df_clean["评论时间_清洗后"] = df_clean["时间和IP属地"].apply(extract_clean_date)
    # 删除无效日期的行
    df_clean = df_clean.dropna(subset=["评论时间_清洗后"], axis=0)
    
    # 5. 新增“评论年份”“评论月份”列（便于后续按时间分组，如IP播出前后对比）
    df_clean["评论年份"] = df_clean["评论时间_清洗后"].dt.year
    df_clean["评论月份"] = df_clean["评论时间_清洗后"].dt.month
    
    # 6. 去重（删除重复评论，避免爬取时重复抓取）
    # 按“清洗后的评论内容+清洗后的时间”去重（确保同一条评论不重复）
    df_clean = df_clean.drop_duplicates(
        subset=["评论内容_清洗后", "评论时间_清洗后"],
        keep="first"  # 保留第一条重复数据
    )
    
    # 7. 调整列顺序（清洗后的核心列放前面，便于查看）
    core_columns = [
        "景区名称", "评论时间_清洗后", "评论年份", "评论月份",
        "评分_清洗后", "评论内容_清洗后", "标题", "评论", "时间和IP属地"
    ]
    # 补充所有原始列（避免丢失用户昵称、游玩时间等潜在信息）
    all_columns = core_columns + [col for col in df_clean.columns if col not in core_columns]
    df_clean = df_clean[all_columns]
    
    return df_clean


# -------------------------- 3. 批量处理三个景区数据（自动清洗+合并） --------------------------
# 存储所有清洗后的有效数据
all_cleaned_data = []

print("开始处理携程三景区评论数据（白哈巴、禾木、喀纳斯）...\n")

for scenic_name, file_path in file_paths.items():
    try:
        # 1. 读取当前景区的原始Excel数据
        raw_df = pd.read_excel(file_path)
        print(f"✅ 成功读取【{scenic_name}】数据：")
        print(f"  - 原始评论总数：{len(raw_df)}条")
        print(f"  - 文件路径：{file_path}\n")
        
        # 2. 调用清洗函数处理数据
        cleaned_df = clean_scenic_comments(raw_df, scenic_name)
        print(f"✅ 【{scenic_name}】数据清洗完成：")
        print(f"  - 有效评论数：{len(cleaned_df)}条")
        print(f"  - 删除无效数据：{len(raw_df) - len(cleaned_df)}条（短评、乱码、异常评分、重复数据）\n")

        all_cleaned_data.append(cleaned_df)

    except FileNotFoundError:
        print(f"❌ 错误：未找到【{scenic_name}】文件！")
        print(f"  - 请确认文件已放在桌面，且路径为：{file_path}\n")

    except Exception as e:
        print(f"❌ 处理【{scenic_name}】时出现错误：{str(e)}")
        print("  - 若报错含“列名不存在”，请打开Excel确认列名是否为“标题、评论、时间和IP属地”\n")


# -------------------------- 4. 合并所有有效数据并保存为最终Excel文件 --------------------------
if all_cleaned_data:
    # 纵向拼接三个景区的清洗后数据
    merged_df = pd.concat(all_cleaned_data, axis=0, ignore_index=True)
    # 最终去重（极端情况：不同景区有完全相同的评论，概率极低）
    merged_df = merged_df.drop_duplicates(subset=["评论内容_清洗后", "评论时间_清洗后"], keep="first")
    
    # 保存到Excel文件（index=False 表示不保留Python的行索引）
    merged_df.to_excel(output_path, sheet_name="三景区清洗后评论", index=False)
    
    # 输出合并结果汇总
    print("=" * 60)
    print("📊 三景区评论数据合并汇总报告")
    print(f"\n各景区有效评论分布：")
    for scenic in merged_df["景区名称"].value_counts().index:
        count = len(merged_df[merged_df["景区名称"] == scenic])
        percentage = (count / len(merged_df)) * 100
        print(f"  - {scenic}：{count}条（占比{percentage:.1f}%）")
    print(f"\n✅ 最终合并文件已保存！")
    print(f"  - 保存路径：{output_path}")
    print(f"  - 可用分析：按景区对比评分、按时间分析IP播出前后评论变化等")
    print("=" * 60)

else:
    print("❌ 未合并任何有效数据！请检查：")
    print("  1. 三个文件是否都放在桌面，且文件名/路径正确；")
    print("  2. Excel列名是否严格为“标题、评论、时间和IP属地”。")

