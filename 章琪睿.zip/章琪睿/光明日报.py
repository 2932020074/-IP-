import pandas as pd
import re
import os
from datetime import datetime

# -------------------------- 1. 配置参数（仅改源文件路径） --------------------------
# 替换为你的Excel文件实际路径
SOURCE_FILE = r"C:\Users\HUAWEI\Desktop\光明日报新闻内容.xlsx"

# 自动生成保存路径（原始文件同目录，加_清洗完成后缀）
source_dir = os.path.dirname(SOURCE_FILE)
source_filename = os.path.splitext(os.path.basename(SOURCE_FILE))[0]
SAVE_FILE = os.path.join(source_dir, f"{source_filename}_清洗完成.xlsx")

# 核心列名（根据你的Excel实际列名修改，示例为通用新闻列名）
CORE_COLS = ["标题", "标题链接", "描述", "ulinks", "来源", "时间", "新闻全文"]

# -------------------------- 2. 读取原始数据 --------------------------
try:
    # 自动适配xlsx/xls格式
    file_ext = os.path.splitext(SOURCE_FILE)[1]
    engine = "openpyxl" if file_ext == ".xlsx" else "xlrd"
    df = pd.read_excel(SOURCE_FILE, engine=engine)
    print(f"✅ 成功读取数据：{len(df)} 行，{len(df.columns)} 列")
    print(f"🔍 数据列名：{list(df.columns)}")
except FileNotFoundError:
    print(f"❌ 错误：未找到文件，请检查路径是否正确！")
    exit()
except Exception as e:
    print(f"❌ 读取失败：{str(e)}")
    exit()

# 检查核心列是否存在
missing_cols = [col for col in CORE_COLS if col not in df.columns]
if missing_cols:
    print(f"❌ 错误：Excel缺失核心列 {missing_cols}，请修改CORE_COLS！")
    exit()

# -------------------------- 3. 文本清洗函数 --------------------------
def clean_text(text):
    if pd.isna(text):
        return ""
    # 移除爬取无效内容
    invalid_str = ["调查问题加载中", "爬取失败", "页面加载异常", "404 Not Found"]
    for s in invalid_str:
        text = text.replace(s, "")
    # 清除多余空格和特殊符号
    text = re.sub(r"\s+", " ", text.strip())
    text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z0-9,。！？；、（）《》：“”‘’\.%@&\-_]", "", text)
    return text

# -------------------------- 4. 数据清洗流程 --------------------------
# 4.1 删除核心列缺失的行
df_clean = df.dropna(subset=CORE_COLS, how="any")
# 4.2 按标题链接去重
df_clean = df_clean.drop_duplicates(subset=["标题链接"], keep="first")
# 4.3 清洗文本列
text_cols = ["标题", "描述", "新闻全文"]
for col in text_cols:
    df_clean[f"{col}_清洗后"] = df_clean[col].apply(clean_text)
    # 过滤清洗后过短的内容
    df_clean = df_clean[df_clean[f"{col}_清洗后"].str.len() >= 5]
# 4.4 时间标准化（适配多种格式）
def format_time(t):
    if pd.isna(t):
        return None
    patterns = [r"\d{4}-\d{2}-\d{2}", r"\d{4}/\d{2}/\d{2}", r"\d{4}年\d{2}月\d{2}日"]
    for p in patterns:
        match = re.search(p, str(t))
        if match:
            return pd.to_datetime(match.group()).date()
    return None

df_clean["时间_标准化"] = df_clean["时间"].apply(format_time)
df_clean = df_clean.dropna(subset=["时间_标准化"])
# 4.5 重置索引
df_clean = df_clean.reset_index(drop=True)

# -------------------------- 5. 保存清洗后数据 --------------------------
try:
    os.makedirs(os.path.dirname(SAVE_FILE), exist_ok=True)
    df_clean.to_excel(SAVE_FILE, index=False, engine="openpyxl")
    print(f"\n✅ 清洗完成！")
    print(f"📁 新文件路径：{SAVE_FILE}")
    print(f"📊 有效数据：{len(df_clean)} 行")
except Exception as e:
    print(f"❌ 保存失败：{str(e)}")
