import pandas as pd
import requests
from bs4 import BeautifulSoup
import time
import random
from datetime import datetime
import os  # 导入os模块用于创建文件夹

# 1. 配置参数
EXCEL_PATH = r"C:\Users\HUAWEI\Desktop\20251217_151311_阿勒泰新闻内容.xlsx"  # 你的Excel文件路径
LINK_COLUMN = "标题链接"  # Excel中存放链接的列名
CONTENT_COLUMN = "新闻全文"  # 新增的存储新闻全文的列名
SAVE_FOLDER = r"C:\Users\HUAWEI\Desktop\Excel文件夹"  # 要保存结果的文件夹路径

HEADERS = {
    'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

# 自动创建保存文件夹（不存在则创建）
if not os.path.exists(SAVE_FOLDER):
    os.makedirs(SAVE_FOLDER)

# 2. 读取Excel中的链接
df = pd.read_excel(EXCEL_PATH, engine="openpyxl")
# 去除空链接和重复链接
df = df.dropna(subset=[LINK_COLUMN])
df = df.drop_duplicates(subset=[LINK_COLUMN])
# 初始化新闻全文字段
if CONTENT_COLUMN not in df.columns:
    df[CONTENT_COLUMN] = ""

# 3. 解析新闻详情页，提取正文
def get_news_content(url):
    """根据链接爬取新闻正文"""
    try:
        # 随机延时，避免反爬
        time.sleep(random.uniform(1, 3))
        # 发送请求
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.encoding = response.apparent_encoding  # 自动识别编码
        response.raise_for_status()  # 捕获HTTP错误

        # 解析网页
        soup = BeautifulSoup(response.text, "lxml")
        
        # 关键：根据网站调整正文选择器
        # 尝试匹配常见的新闻正文标签，可根据目标网站调整
        content_tag = soup.find("div", class_=["content", "article-body", "detail-content", "main-content"])
        if not content_tag:
            # 若未找到，尝试选取所有<p>标签的正文内容（排除带class的广告标签）
            p_tags = soup.find_all("p", class_=False)
            content = "\n".join(p.get_text(strip=True) for p in p_tags if p.get_text(strip=True))
        else:
            content = content_tag.get_text(strip=True)
        return content
    except Exception as e:
        return f"爬取失败：{str(e)}"

# 4. 遍历链接并爬取内容
total = len(df)
for idx, row in df.iterrows():
    url = row[LINK_COLUMN]
    print(f"正在爬取({idx+1}/{total})：{url}")
    content = get_news_content(url)
    df.loc[idx, CONTENT_COLUMN] = content

# 5. 保存爬取结果（生成带时间戳的文件名，避免重名）
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
save_filename = f"{timestamp}_阿勒泰新闻内容.xlsx"
save_path = os.path.join(SAVE_FOLDER, save_filename)  # 拼接文件夹和文件名
df.to_excel(save_path, index=False, engine="openpyxl")
print(f"爬取完成！结果已保存到：{save_path}")
