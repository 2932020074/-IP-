import pandas as pd
import re
import os
from datetime import datetime

# -------------------------- 1. 配置参数（已匹配你的Excel列名） --------------------------
SOURCE_FILE = r"C:\Users\HUAWEI\Desktop\news_content.xlsx"  # 你的Excel路径
source_dir = os.path.dirname(SOURCE_FILE)
source_filename = os.path.splitext(os.path.basename(SOURCE_FILE))[0]
SAVE_FILE = os.path.join(source_dir, f"{source_filename}_清洗完成.xlsx")

# 核心列名：用你实际的列名["标题", "标题链接", "时间", "新闻全文"]
CORE_COLS = ["标题", "标题链接", "时间", "新闻全文"]

# -------------------------- 2. 读取原始数据 --------------------------
try:
    file_ext = os.path.splitext(SOURCE_FILE)[1]
    engine = "openpyxl" if file_ext == ".xlsx" else "xlrd"
    df = pd.read_excel(SOURCE_FILE, engine=engine)
    print(f"✅ 成功读取数据：{len(df)} 行，{len(df.columns)} 列")
    print(f"🔍 列名：{list(df.columns)}")
except FileNotFoundError:
    print(f"❌ 错误：未找到文件，请检查路径！")
    exit()
except Exception as e:
    print(f"❌ 读取失败：{str(e)}")
    exit()

# -------------------------- 3. 文本清洗函数 --------------------------
def clean_text(text):
    if pd.isna(text):
        return ""
    text = text.replace("调查问题加载中", "").replace("爬取失败", "")
    text = re.sub(r"\s+", " ", text.strip())
    text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z0-9,。！？；、（）《》：“”]", "", text)
    return text

# -------------------------- 4. 数据清洗流程 --------------------------
# 4.1 删除缺失值
df_clean = df.dropna(subset=CORE_COLS, how="any")
# 4.2 按标题链接去重
df_clean = df_clean.drop_duplicates(subset="标题链接", keep="first")
# 4.3 清洗文本列
text_cols = ["标题", "新闻全文"]
for col in text_cols:
    df_clean[f"{col}_清洗后"] = df_clean[col].apply(clean_text)
# 4.4 时间标准化（用你实际的"时间"列）
def format_time(t):
    if pd.isna(t):
        return None
    return pd.to_datetime(str(t), errors="coerce").date() if t else None
df_clean["时间_标准化"] = df_clean["时间"].apply(format_time)
df_clean = df_clean.dropna(subset=["时间_标准化"])

# -------------------------- 5. 保存新文件 --------------------------
os.makedirs(os.path.dirname(SAVE_FILE), exist_ok=True)
df_clean.to_excel(SAVE_FILE, index=False, engine="openpyxl")
print(f"\n✅ 清洗完成！新文件：{SAVE_FILE}")
print(f"📊 有效数据：{len(df_clean)} 行")
