import pandas as pd
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")  # 忽略无关警告

# 1. 基础配置（解决中文显示+图表样式）
plt.rcParams["font.sans-serif"] = ["SimHei", "DejaVu Sans"]  # 适配中文+英文
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示异常
plt.rcParams["figure.facecolor"] = "white"  # 图表背景设为白色

# 2. 读取清洗后的数据（需替换为你的实际文件路径）
# 路径格式示例：r"C:\Users\你的用户名\Desktop\Excel文件夹\新闻数据_清洗完成.xlsx"
df = pd.read_excel(
    r"C:\Users\HUAWEI\Desktop\Excel文件夹\新闻数据_清洗完成.xlsx",
    engine="openpyxl",  # 适配.xlsx格式
    usecols=["标题", "tip-pubtime"]  # 仅读取需要的列，提升效率
)

# 3. 时间列处理（关键：适配Excel中的`tip-pubtime`列）
# 解析时间格式，无效时间转为空值
df["tip-pubtime"] = pd.to_datetime(df["tip-pubtime"], errors="coerce")
# 删除时间为空的无效行
df = df.dropna(subset=["tip-pubtime"])
# 提取“日期”（去掉时分秒，方便按天统计）
df["发布日期"] = df["tip-pubtime"].dt.date

# 4. 按日期统计新闻数量（按时间排序）
time_count = df["发布日期"].value_counts().sort_index()

# 5. 绘制趋势图（美观+信息清晰）
fig, ax = plt.subplots(figsize=(14, 7))  # 图表大小（宽14，高7）

# 绘制折线图：蓝色线条+圆形标记，线条粗细2
time_count.plot(
    kind="line",
    ax=ax,
    color="#1f77b4",  # 专业蓝色
    marker="o",        # 数据点用圆形标记
    markersize=6,      # 标记大小
    linewidth=2,       # 线条粗细
    alpha=0.8          # 透明度（避免刺眼）
)

# 图表细节优化
ax.set_title(
    "《我的阿勒泰》相关新闻发布时间趋势",
    fontsize=16,
    fontweight="bold",
    pad=20  # 标题与图表间距
)
ax.set_xlabel("发布日期", fontsize=12, labelpad=10)
ax.set_ylabel("新闻发布数量（条）", fontsize=12, labelpad=10)

# 坐标轴样式
ax.tick_params(axis="x", rotation=45, labelsize=10)  # 日期旋转45°，避免重叠
ax.tick_params(axis="y", labelsize=10)
ax.grid(axis="y", linestyle="--", alpha=0.5)  # 仅显示水平网格线，更简洁
ax.spines["top"].set_visible(False)  # 隐藏顶部边框
ax.spines["right"].set_visible(False)  # 隐藏右侧边框

# 6. 保存图片+显示（可选：保存为高清图片）
plt.tight_layout()  # 自动调整布局，避免标签被截断
plt.savefig(
    r"C:\Users\HUAWEI\Desktop\阿勒泰新闻时间趋势图.png",
    dpi=300,  # 高清分辨率（300dpi适合打印/汇报）
    bbox_inches="tight"  # 完整保存图表（无裁剪）
)
plt.show()

# 7. 打印数据统计结果（便于核对）
print("="*50)
print("数据统计结果：")
print(f"清洗后有效新闻总数：{len(df)} 条")
print(f"时间范围：{df['发布日期'].min()} ~ {df['发布日期'].max()}")
print(f"新闻最多单日：{time_count.idxmax()}（{time_count.max()} 条）")
print("="*50)
