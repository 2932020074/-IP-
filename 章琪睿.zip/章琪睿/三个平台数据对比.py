import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter
import warnings
import os
from datetime import datetime

# 忽略警告
warnings.filterwarnings("ignore")

# -------------------------- 1. 基础配置（修复中文显示问题） --------------------------
plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]  # 兼容中文字体
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题
plt.rcParams["font.family"] = "sans-serif"
plt.rcParams["figure.facecolor"] = "white"
sns.set_style("whitegrid")

# -------------------------- 2. 手动指定三个文件的路径（替换为你的实际路径） --------------------------
file_people = r"C:\Users\HUAWEI\Desktop\新闻数据_清洗完成.xlsx"    # 人民网文件路径
file_gmrb = r"C:\Users\HUAWEI\Desktop\光明日报新闻内容.xlsx"      # 光明日报文件路径
file_xinhua = r"C:\Users\HUAWEI\Desktop\news_content.xlsx"       # 新华网文件路径

# -------------------------- 3. 读取并适配每个平台的列名（已按你的Excel修正） --------------------------
# ========== 人民网数据适配（列名：tip-pubtime） ==========
df_people = pd.read_excel(file_people, engine="openpyxl")
df_people["统一_标题"] = df_people["标题"]          
df_people["统一_时间"] = pd.to_datetime(df_people["tip-pubtime"], errors="coerce")  # 修正为tip-pubtime
df_people["统一_来源"] = "人民网"
df_people["统一_正文"] = df_people["新闻全文"]      

# ========== 光明日报数据适配（列名：标题/时间/新闻全文） ==========
df_gmrb = pd.read_excel(file_gmrb, engine="openpyxl")
df_gmrb["统一_标题"] = df_gmrb["标题"]              
df_gmrb["统一_时间"] = pd.to_datetime(df_gmrb["时间"], errors="coerce")
df_gmrb["统一_来源"] = "光明日报"
df_gmrb["统一_正文"] = df_gmrb["新闻全文"]           

# ========== 新华网数据适配（列名：标题/时间/新闻全文） ==========
df_xinhua = pd.read_excel(file_xinhua, engine="openpyxl")
df_xinhua["统一_标题"] = df_xinhua["标题"]           
df_xinhua["统一_时间"] = pd.to_datetime(df_xinhua["时间"], errors="coerce")
df_xinhua["统一_来源"] = "新华网"
df_xinhua["统一_正文"] = df_xinhua["新闻全文"]       

# -------------------------- 4. 合并数据并清洗 --------------------------
cols_keep = ["统一_标题", "统一_时间", "统一_来源", "统一_正文"]
data = pd.concat([df_people[cols_keep], df_gmrb[cols_keep], df_xinhua[cols_keep]], ignore_index=True)
data = data.dropna(subset=["统一_时间"])  # 删除无效时间行
data["发布月份"] = data["统一_时间"].dt.to_period("M")  # 提取月份

# 打印数据统计，验证读取结果
print("\n=== 数据读取成功 ===")
print(f"合并后有效新闻总数：{len(data)} 条")
print(f"各平台新闻数量：\n{data['统一_来源'].value_counts()}")

# -------------------------- 5. 关键词提取 --------------------------
def extract_keywords(text):
    text = str(text)
    keywords = ["阿勒泰", "我的阿勒泰", "文旅", "冰雪", "文创", "旅游", "牧民转场", "国际传播"]
    return [kw for kw in keywords if kw in text]

# 合并标题和正文提取关键词
data["关键词"] = (data["统一_标题"] + data["统一_正文"]).apply(extract_keywords)
all_keywords = [kw for sublist in data["关键词"] for kw in sublist]
keyword_count = Counter(all_keywords)

# -------------------------- 6. 绘制多维度可视化图表（适配低版本matplotlib） --------------------------
fig, ((ax1, ax2), (ax3, _)) = plt.subplots(2, 2, figsize=(16, 12), gridspec_kw={"width_ratios": [2, 1]})

# 适配低版本的字体配置：仅指定中文字体家族，字号单独传参
font_family = {"family": "SimHei"}

# 子图1：时间趋势折线图
monthly_source = data.groupby(["发布月份", "统一_来源"]).size().unstack(fill_value=0)
for source in monthly_source.columns:
    ax1.plot(range(len(monthly_source.index)), monthly_source[source], marker="o", markersize=6, linewidth=2.5, label=source)
# 标题：单独设置字号和加粗，字体用font_family
ax1.set_title("《我的阿勒泰》新闻发布时间趋势（按月份）", fontsize=14, fontweight="bold", **font_family)
ax1.set_xlabel("发布月份", fontsize=10, **font_family)  # 坐标轴标签单独设字号
ax1.set_ylabel("新闻数量", fontsize=10, **font_family)
ax1.set_xticks(range(len(monthly_source.index)))
ax1.set_xticklabels([str(i) for i in monthly_source.index], rotation=45, fontsize=10, **font_family)
# 图例：低版本matplotlib用prop传字体，不含字号
ax1.legend(prop={"family": "SimHei"}, fontsize=10)
ax1.text(0.02, 0.98, 
         "图表类型：时间序列折线图\n用途：观察各平台报道热度变化", 
         transform=ax1.transAxes, 
         fontsize=10, 
         bbox=dict(boxstyle="round", facecolor="lightblue", alpha=0.5), 
         **font_family)

# 子图2：平台分布饼图
source_count = data["统一_来源"].value_counts()
colors = ["#FF6B6B", "#4ECDC4", "#45B7D1"]
ax2.pie(source_count.values, 
        labels=source_count.index, 
        colors=colors, 
        autopct="%1.1f%%", 
        explode=(0.05, 0.05, 0.05), 
        shadow=True, 
        startangle=90,
        textprops={"family": "SimHei", "fontsize": 10})  # 饼图标签直接传参
ax2.set_title("三大平台新闻数量占比", fontsize=14, fontweight="bold", **font_family)
ax2.text(0.5, -1.2, 
         "图表类型：饼图\n用途：对比各平台报道频次", 
         transform=ax2.transAxes, 
         fontsize=10, 
         ha="center", 
         bbox=dict(boxstyle="round", facecolor="lightgreen", alpha=0.5), 
         **font_family)

# 子图3：关键词频次水平柱状图
top8_kw = dict(keyword_count.most_common(8))
bars = ax3.barh(list(top8_kw.keys()), list(top8_kw.values()), color="#FFA07A", edgecolor="black")
ax3.set_yticklabels(list(top8_kw.keys()), fontsize=10, **font_family)  # y轴标签单独设字号
for i, v in enumerate(top8_kw.values()):
    ax3.text(v + 0.1, i, str(v), ha="left", va="center", fontweight="bold", fontsize=10, **font_family)
ax3.set_title("新闻核心关键词提及频次（Top8）", fontsize=14, fontweight="bold", **font_family)
ax3.set_xlabel("提及次数", fontsize=10, **font_family)
ax3.text(0.02, 0.98, 
         "图表类型：水平柱状图\n用途：识别新闻核心话题", 
         transform=ax3.transAxes, 
         fontsize=10, 
         bbox=dict(boxstyle="round", facecolor="lightyellow", alpha=0.5), 
         **font_family)

# -------------------------- 7. 自动生成文件并保存图表 --------------------------
save_folder = r"C:\Users\HUAWEI\Desktop"  # 保存到桌面，可自行修改
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
save_path = os.path.join(save_folder, f"阿勒泰新闻分析图_{timestamp}.png")

plt.tight_layout()
plt.savefig(save_path, dpi=300, bbox_inches="tight")
plt.show()

# 输出最终统计
print("\n=== 分析完成 ===")
print(f"时间范围：{data['统一_时间'].min().date()} ~ {data['统一_时间'].max().date()}")
print(f"最热关键词：{max(keyword_count, key=keyword_count.get)}（{max(keyword_count.values())}次）")
print(f"图表已自动保存至：{save_path}")
