import matplotlib.pyplot as plt
import seaborn as sns
import jieba
from collections import Counter
import re
from snownlp import SnowNLP

# ---------------------- 1. 数据预处理 ----------------------
def preprocess_text(text):
    text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z\s]', '', text)
    text = re.sub(r'\d+', '', text)
    stop_words = {'的', '了', '是', '在', '和', '有', '我', '他', '她', '它', '我们', '你们', '他们', '这', '那', '个', '也', '就', '都', '而', '及', '与'}
    words = jieba.lcut(text)
    return [word for word in words if word not in stop_words and len(word) > 1]

# 替换为你的新闻文本（可多篇拼接）
news_text = """
巴太的小马、托肯和她的洗衣板热播剧《我的阿勒泰》里多个熟悉的场景摇身一变成了冰箱贴、书签、驱蚊手环、笔记本等。跟剧打卡阿勒泰的同时，争相购买火爆出圈的文创纪念品，成为这个夏季很多游客旅游的新选择。党的二十届三中全会提出，激发全民族文化创新创造活力。围绕《我的阿勒泰》，阿勒泰地区积极借助影视IP赋能，推动城市文旅业融合发展，实现影视和文旅的双向奔赴。阿勒泰地区文化体育广播电视和旅游局副局长王新慧说，影视IP带动旅游热是一种新趋势，能够促进城市文旅产业发展，提升城市形象，获得社会影响和经济效益的双赢。哈巴河县桦城旅游开发有限公司依据爱奇艺《我的阿勒泰》IP商标授权，共推出73款周边产品。7月25日，其中3款1000件周边产品刚一到货，就被快速分送到哈巴河县4个运营点补货。不仅是文创，抓住热播剧的流量密码，阿勒泰推动着更大范围和更深层次的资源与文化整合。新疆阿山酒业有限责任公司重新升级设计砰砰酒；哈巴河县雅居床服有限责任公司推出文秀奶奶驼绒护腰；阿勒泰市金钥匙职业培训学校创新设计我的阿勒泰系列刺绣作品IP商标授权，是推动文化和旅游深度融合的重要契机。哈巴河县文化体育广播电视和旅游局党组书记杨志琴说。热播剧衍生出多个打卡新地标，搭建出多个文旅商新场景，文化和旅游深度融合的同时，还巧妙地嵌入商业活动。哈巴河县围绕巴太树等剧中十余处点位打造彩虹布拉克景区，游客可以在张凤侠小卖部购物，在好得很拉条子饭馆品尝过油肉拌面，满足沉浸式全新体验。5月中旬至今，该景区已接待游客77万余人次。剧中文秀的包、文秀奶奶的拐杖等老物件，都出自布尔津县牧魂民宿。趁着热度，布尔津县将这个民宿的家庭展馆打造成研学点，目前已接待400余名疆内外研学游客。为进一步将网络流量转化为打卡人流，以我的阿勒泰为主题的系列活动也层出不穷：7月23日，一场旷野音乐会在哈巴河县唱响彩虹和布拉克的歌；哈巴河县每天都有非遗沃尔铁克表演，游客可参与经典剧情互动体验；布尔津县定期举办读书分享会、迷你跑、迷你小剧场等活动；青河县打造黑肥皂手工坊打卡体验点；福海县举办草原运动会；吉木乃县通过还原部分剧中场景来展示牧场生活这些新场景、新活动，让游客的阿勒泰之旅不仅是观光，还能深度体验文化，感受非遗魅力。文化是旅游的魂。当影视热潮褪去，城市能否留住旅游热度，最终检验的还是当地的人文底蕴。布尔津县文化体育广播电视和旅游局局长武雷说，将支持这些活动常态化进行，通过更多潮流表达，得到更多年轻人的青睐，进一步激活文旅产业融合发展一池春水。
"""

# 分词+词频统计
words = preprocess_text(news_text)
word_freq = Counter(words).most_common(12)  # 取前12个高频词
words_list, freq_list = zip(*word_freq) if word_freq else ([], [])

# ---------------------- 2. SnowNLP 中文情感分析 ----------------------
sentences = news_text.split('。')
sentences = [s.strip() for s in sentences if s.strip()]
sentiment_results = []

for sent in sentences:
    s = SnowNLP(sent)
    polarity = s.sentiments  # 情感极性：0（负面）~1（正面）
    # 自定义标签划分
    if polarity > 0.6:
        label = "Positive"
    elif polarity < 0.4:
        label = "Negative"
    else:
        label = "Neutral"
    sentiment_results.append({
        "sentence": sent,
        "polarity": polarity,
        "label": label
    })

# 统计情感标签分布
label_counts = Counter([res["label"] for res in sentiment_results])

# ---------------------- 3. Matplotlib+Seaborn 可视化 ----------------------
# 设置图表风格和中文字体
sns.set_style("whitegrid")
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 创建 1行3列 子图布局
fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18, 6))
fig.suptitle('新闻文本分析可视化报告 (Matplotlib+Seaborn)', fontsize=16, fontweight='bold')

# 子图1：高频词柱状图（Seaborn 配色）
if words_list:
    sns.barplot(x=list(words_list), y=list(freq_list), ax=ax1, palette="viridis")
    ax1.set_title('Top12 高频词统计', fontsize=12)
    ax1.set_xlabel('关键词')
    ax1.set_ylabel('频次')
    ax1.tick_params(axis='x', rotation=45)

# 子图2：情感标签分布饼图
labels = list(label_counts.keys())
sizes = list(label_counts.values())
colors = sns.color_palette("pastel", len(labels))
ax2.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
ax2.set_title('情感标签分布', fontsize=12)

# 子图3：情感极性分布散点图
polarities = [res["polarity"] for res in sentiment_results]
labels_scatter = [res["label"] for res in sentiment_results]
sns.scatterplot(x=range(len(polarities)), y=polarities, hue=labels_scatter, ax=ax3,
                palette={"Positive": "green", "Negative": "red", "Neutral": "blue"},
                s=100, alpha=0.7, edgecolor="black")
ax3.set_title('情感极性分布', fontsize=12)
ax3.set_xlabel('句子序号')
ax3.set_ylabel('情感极性（0-1）')
ax3.axhline(y=0.5, color='gray', linestyle='--', alpha=0.5)  # 中性分界线

# 调整子图间距
plt.tight_layout()
plt.savefig('news_analysis_seaborn.png', dpi=300, bbox_inches='tight')
plt.show()

# ---------------------- 4. 输出分析结果 ----------------------
print("=== 分句情感分析结果 ===")
for res in sentiment_results:
    print(f"句子: {res['sentence']}")
    print(f"极性: {res['polarity']:.2f}, 标签: {res['label']}\n")
